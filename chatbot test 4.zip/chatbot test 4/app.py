import os
from flask import Flask, request, jsonify, render_template
from openai import AzureOpenAI
from pymongo import MongoClient
import requests

# ====== MongoDB Atlas Connection ======
MONGO_URI = "mongodb+srv://gruhadmin:<db_password>@gruh-cluster.tjfcabg.mongodb.net/?retryWrites=true&w=majority&appName=gruh-cluster"
MONGO_URI = MONGO_URI.replace("<db_password>", "Gruh1")

mongo_client = MongoClient(MONGO_URI)
db = mongo_client["gruh_chatbot"]
users_collection = db["users"]

# ====== Azure OpenAI Config ======
endpoint = os.getenv("ENDPOINT_URL", "https://chatassistgruh.openai.azure.com/openai/deployments/gpt-35-turbo/chat/completions?api-version=2025-01-01-preview")
deployment = os.getenv("DEPLOYMENT_NAME", "gpt-35-turbo")
subscription_key = os.getenv("AZURE_OPENAI_API_KEY", "03XOnRpTdFpP4boGsLQmDYjq0Ao5GoETDaCAujfS4UJLeSSKf0TdJQQJ99BDACYeBjFXJ3w3AAABACOGhV72")

search_endpoint = os.getenv("SEARCH_ENDPOINT", "https://gruhcustomchat.search.windows.net")
search_key = os.getenv("SEARCH_KEY", "VPytYaGPk3N7SkuMA8O0z55cX74FSPCYTIVtOmDSXLAzSeAOUhcv")

client = AzureOpenAI(
    azure_endpoint=endpoint,
    api_key=subscription_key,
    api_version="2025-01-01-preview",
)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

# ====== Save user details ======
@app.route('/save-user', methods=['POST'])
def save_user():
    data = request.json
    name = data.get('name')
    contact = data.get('contact')

    if not name or not contact:
        return jsonify({"message": "Missing name or contact"}), 400

    try:
        users_collection.insert_one({
            "name": name,
            "contact": contact
        })
        return jsonify({"message": "User saved successfully!"}), 200
    except Exception as e:
        return jsonify({"message": f"Database error: {str(e)}"}), 500

# ====== Search data from Azure Cognitive Search ======
def search_data_from_azure(query):
    search_url = f"{search_endpoint}/indexes/gruhchat/docs/search?api-version=2021-04-30-Preview"
    headers = {
        "Content-Type": "application/json",
        "api-key": search_key
    }
    body = {
        "search": query,
        "top": 3
    }

    response = requests.post(search_url, headers=headers, json=body)
    if response.status_code == 200:
        search_results = response.json()
        if 'value' in search_results:
            return [doc.get('content', '') for doc in search_results['value']]
    return []

# ====== Chat API ======
@app.route('/chat', methods=['POST'])
def chat_api():
    user_message = request.json.get("message", "")

    if not user_message:
        return jsonify({"response": "No message received."}), 400

    # STEP 1: Search data from Azure Search
    search_results = search_data_from_azure(user_message)

    # STEP 2: Prepare context
    context_data = "\n".join(search_results)

    # STEP 3: Create prompt
    if context_data:
        prompt = f"Use the following information to answer the user's question:\n{context_data}\n\nQuestion: {user_message}\nAnswer:"
    else:
        prompt = f"Answer the following question:\n\nQuestion: {user_message}\nAnswer:"

    chat_prompt = [{"role": "system", "content": prompt}]

    # STEP 4: Query OpenAI
    completion = client.chat.completions.create(
        model=deployment,
        messages=chat_prompt,
        max_tokens=800,
        temperature=0.7,
        top_p=0.95,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None,
        stream=False
    )

    response_text = completion.choices[0].message.content.strip()

    return jsonify({"response": response_text})

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
