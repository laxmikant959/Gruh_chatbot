const messagesContainer = document.getElementById('messages');
const userInput = document.getElementById('userInput'); 
const sendBtn = document.querySelector('#user-details button'); 
const closeBtn = document.getElementById('close-chat');

// Function to append messages to the chat container
function appendMessage(content, sender) {
    const messageEl = document.createElement('div');
    messageEl.classList.add('message', sender);

    const icon = document.createElement('img');
    icon.classList.add('icon');
    icon.alt = sender === 'bot' ? 'Bot Icon' : 'User Icon';
    icon.src = sender === 'bot' ? 'static/gruh_png.jpg' : 'static/user2.png';

    const textContainer = document.createElement('div');
    textContainer.classList.add('text');
    textContainer.textContent = content;

    messageEl.appendChild(icon);
    messageEl.appendChild(textContainer);

    messagesContainer.appendChild(messageEl);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Function to handle sending messages
async function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    appendMessage(message, 'user');
    userInput.value = '';

    try {
        const response = await fetch('/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: message })
        });

        if (!response.ok) {
            throw new Error('Server error');
        }

        const data = await response.json();
        const botReply = data.response || "Sorry, I couldn't process that.";
        appendMessage(botReply, 'bot');

    } catch (error) {
        appendMessage("Error: " + error.message, 'bot');
    }
}

userInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendMessage();
});

// 🆕 Close button functionality
closeBtn.addEventListener('click', () => {
    document.getElementById('chatbox').classList.add('hidden');
    document.getElementById('chat-icon').classList.remove('hidden');
});
